//
//  TableViewCell.swift
//  API_Call_Swift
//
//  Created by Mitesh Ramani on 4/10/18.
//  Copyright © 2018 Mitesh Ramani. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var lbl_title: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
