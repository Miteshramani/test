//
//  ViewController.swift
//  API_Call_Swift
//
//  Created by Mitesh Ramani on 4/10/18.
//  Copyright © 2018 Mitesh Ramani. All rights reserved.
//
import UIKit
import Alamofire
import SVProgressHUD
class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var page = 1;
    var NoPage: Int = 0
    @IBOutlet weak var tbl_view: UITableView!
      let cellReuseIdentifier = "TableViewCell"
    var ResultArray = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
        Home_APi()
    }
        // Do any additional setup after loading the view, typically from a nib.
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func Home_APi(){
        if page < 1
        {
           return
        }
        let header = ["Content-Type":"application/json"]
        let dicParameter =  ["Key" : "Value",
                             "Key" : "Value",
                             "Key" : "Value"
                            ]
        //SVProgressHUD.show()
        let urlString = "\(API.HOME)&page=\(page)"
        print(urlString)
        request(urlString, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: header).responseString(completionHandler: { (response) in
            //SVProgressHUD.dismiss()
            let value = response.result.value!
            let json = self.convertToDictionary(text: value )
            if json != nil {
                let comment = json
                    let data  = comment! as [String : AnyObject]
                if self.page == 1
                {
                    self.ResultArray  =  (data["results"] as! NSArray).mutableCopy()as! NSMutableArray
                }
                else
                {
                    let array = data["results"] as! NSArray
                    self.ResultArray.addObjects(from: array as! [Any])
                }
                self.NoPage = Int(ceil(Double(self.ResultArray.count/20)))
                if(self.page <= self.NoPage)
                {
                    self.page = self.page + 1
                    self.Home_APi()
                }
                self.tbl_view.reloadData()
               
            }else
            {
               self.page = 1
            }
        })
    }
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
    // number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.ResultArray.count
    }
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//
//        // create a new cell if needed or reuse an old one
//        if  page > 1 && self.ResultArray.count - 1 == indexPath.row
//        {
//       }
        let lastSectionIndex = tableView.numberOfSections - 1
        let lastRowIndex = tableView.numberOfRows(inSection: lastSectionIndex) - 1
        if indexPath.section ==  lastSectionIndex && indexPath.row == lastRowIndex {
            let spinner = UIActivityIndicatorView(activityIndicatorStyle: .gray)
            spinner.startAnimating()
            spinner.frame = CGRect(x: CGFloat(0), y: CGFloat(0), width: tableView.bounds.width, height: CGFloat(44))
            tbl_view.tableFooterView = spinner
            tbl_view.tableFooterView?.isHidden = false
            }
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier, for: indexPath) as! TableViewCell
        // set the text from the data model
        
        let Title = self.ResultArray[indexPath.row] as! [String:AnyObject]
        //print(Title)
        cell.lbl_title.text = (Title["title"] as! String)
        return cell
    }
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("You tapped cell number \(indexPath.row).")
    }
}

