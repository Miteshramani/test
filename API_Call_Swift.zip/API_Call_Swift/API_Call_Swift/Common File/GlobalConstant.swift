

import Foundation
import UIKit
let Live = "https://api.themoviedb.org/3/movie"
struct API
{
    //static var API_BASE_URL  = Live
    static var API_BASE_URL  = Live
    static var HOME                         = API_BASE_URL + "/popular?api_key=52385ff92cb9105e52d86c4786293ce8"
    static var GET_REGISTER_DATA             = API_BASE_URL + "/user/signup"
    static var GET_RESET_PASSWORD            = API_BASE_URL + "/user/reset-password"
    
}

struct ColorCode
{
    static var hex1 = "e57373"
    static var hex2 = "f06292"
    static var hex3 = "ba68c8"
    static var hex4 = "9575cd"
    static var hex5 = "7986cb"
    static var hex6 = "64b5f6"
    static var hex7 = "4fc3f7"
    static var hex8 = "4dd0e1"
    static var hex9 = "4db6ac"
    static var hex10 = "81c784"
    static var hex11 = "aed581"
    static var hex12 = "ff8a65"
    static var hex13 = "d4e157"
    static var hex14 = "ffd54f"
    static var hex15 = "ffb74d"
    static var hex16 = "a1887f"
    static var hex17 = "90a4ae"
    
    static var COLOR_APP = "009688"
    static var COLOR_NOTI = "e0f5fe"
    static var COLOR_BLACK = "101010"
    static var COLOR_DARK_GRAY = "9e9e9e"
    static var COLOR_LIGHT_GRAY = "f0f0f0"
    static var COLOR_PLACEHOLDER = "00796B"
    static var COLOR_BORDER = "FFFFFF"
}

struct FONT {
    static var FONT_BOLD     =  "HelveticaNeue-Bold"
    static var FONT_RAGULAR  =  "HelveticaNeue"
    static var FONT_LIGHT    =  "HelveticaNeue-Light"
}

struct IMAGESIZE {
    static var IMAGE_WIDTH     =  800
    static var IMAGE_HEIGHT    =  800
    static var IMAGE_QUALITY   =  0.7
}

enum UIUserInterfaceIdiom : Int
{
    case Unspecified
    case Phone
    case Pad
}

struct UISCREEN {
    static var SCREEN_WIDTH = UIScreen.main.bounds.size.width
    static var SCREEN_HEIGHT = UIScreen.main.bounds.size.height
    static var SCREEN_MAX_LENGTH    = max(SCREEN_WIDTH, SCREEN_HEIGHT)
    static var SCREEN_MIN_LENGTH    = min(SCREEN_WIDTH, SCREEN_HEIGHT)
}

struct DEVICE
{
    static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && UISCREEN.SCREEN_MAX_LENGTH < 568.0
    static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && UISCREEN.SCREEN_MAX_LENGTH == 568.0
    static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && UISCREEN.SCREEN_MAX_LENGTH == 667.0
    static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && UISCREEN.SCREEN_MAX_LENGTH == 736.0
    static let IS_IPHONE_X        = UIDevice.current.userInterfaceIdiom == .phone && UISCREEN.SCREEN_MAX_LENGTH == 812.0
    static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && UISCREEN.SCREEN_MAX_LENGTH == 1024.0
    static let IS_IPAD_PRO          = UIDevice.current.userInterfaceIdiom == .pad && UISCREEN.SCREEN_MAX_LENGTH == 1366.0
}

struct VERSION{
    static let SYS_VERSION_FLOAT = (UIDevice.current.systemVersion as NSString).floatValue
    static let iOS7 = (SYS_VERSION_FLOAT < 8.0 && SYS_VERSION_FLOAT >= 7.0)
    static let iOS8 = (SYS_VERSION_FLOAT >= 8.0 && SYS_VERSION_FLOAT < 9.0)
    static let iOS9 = (SYS_VERSION_FLOAT >= 9.0 && SYS_VERSION_FLOAT < 10.0)
}

struct HEADER {
    //    static let REQUEST_TOKEN = AppPrefsManager.sharedInstance.getRequestToken() as String
    static let USER_AGENT = "budgetplanner iPhone 321"
}

struct HTTP_METHOD {
    static var GET      =  "GET"
    static var POST     =  "POST"
}



//let Default       =       UserDefaults.standard
