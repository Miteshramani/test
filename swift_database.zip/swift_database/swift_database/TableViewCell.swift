//
//  TableViewCell.swift
//  swift_database
//
//  Created by Mitesh Ramani on 5/14/18.
//  Copyright © 2018 Mitesh Ramani. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
 
    @IBOutlet weak internal var lbl_title: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
