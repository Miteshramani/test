//
//  democlass.swift
//  swift_database
//
//  Created by Mitesh Ramani on 5/15/18.
//  Copyright © 2018 Mitesh Ramani. All rights reserved.
//

import UIKit

class democlass: NSObject {
    var id : String = String()
    var title : String = String()
}
