//
//  Modeldata.swift
//  swift_database
//
//  Created by Mitesh Ramani on 5/15/18.
//  Copyright © 2018 Mitesh Ramani. All rights reserved.
//

import UIKit
let sharedInstance = Modeldata()
class Modeldata: NSObject {

    
    var database: FMDatabase? = nil
    
    class func getInstance() -> Modeldata
    {
        if(sharedInstance.database == nil)
        {
            let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("demo.sqlite").path
            sharedInstance.database = FMDatabase(path: path)
            print(path)
            
        }
        return sharedInstance
    }
    //Insert data
    func addPersonData(personinfo: democlass) -> Bool {
        sharedInstance.database!.open()
        
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO data (title) VALUES (?)", withArgumentsIn: [personinfo.title])
        sharedInstance.database!.close()
        return isInserted
    }
    
    func getAllData() -> NSMutableArray {
        sharedInstance.database!.open()
        //let personinfo : PersonInfo = PersonInfo()
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM data", withArgumentsIn: [])
        let resultProductInfo : NSMutableArray = NSMutableArray()
        if (resultSet != nil) {
            while resultSet.next() {
                let productinfo : democlass = democlass()
                productinfo.id = resultSet.string(forColumn: "id")!
                productinfo.title = resultSet.string(forColumn: "title")!
                resultProductInfo.add(productinfo)
            }
        }
        sharedInstance.database!.close()
        return resultProductInfo
    }
    
//    //Get All Data for Person
//    func getAllLoginData() -> NSMutableArray {
//        sharedInstance.database!.open()
//        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM person", withArgumentsIn: [])
//        let resultPersonInfo : NSMutableArray = NSMutableArray()
//        if (resultSet != nil) {
//            while resultSet.next() {
//                let personinfo : PersonInfo = PersonInfo()
//                personinfo.id = resultSet.string(forColumn: "id")!
//                personinfo.name = resultSet.string(forColumn: "name")!
//                personinfo.email = resultSet.string(forColumn: "email")!
//                personinfo.password = resultSet.string(forColumn: "password")!
//                personinfo.gender = resultSet.string(forColumn: "gender")!
//                personinfo.birthdate = resultSet.string(forColumn: "birthdate")!
//                //personinfo.image = resultSet.string(forColumn: "image")!
//                personinfo.country = resultSet.string(forColumn: "country")!
//                resultPersonInfo.add(personinfo)
//            }
//        }
//        sharedInstance.database!.close()
//        return resultPersonInfo
//    }
    
//    // Update Data
//    func updateProductData(productinfo: ProductInfo) -> Bool {
//        sharedInstance.database!.open()
//        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE product SET name=?, image=?, price=?, company=?, description=? WHERE id=?", withArgumentsIn: [productinfo.name, productinfo.image, productinfo.price, productinfo.company, productinfo.discription, productinfo.id])
//        sharedInstance.database!.close()
//        return isUpdated
//    }
//    
//    
//    
//    //Delete Data
//    func deleteProductData(productinfo: ProductInfo) -> Bool {
//        sharedInstance.database!.open()
//        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM product WHERE id=?", withArgumentsIn: [productinfo.id])
//        sharedInstance.database!.close()
//        return isDeleted
//    }
    
   
}
