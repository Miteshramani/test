//
//  ViewController.swift
//  swift_database
//
//  Created by Mitesh Ramani on 5/14/18.
//  Copyright © 2018 Mitesh Ramani. All rights reserved.
//

import UIKit
import Alamofire
class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
     var ItemsArray = NSArray()
    var resultData : NSMutableArray!
    var type = 1
    @IBOutlet weak var tbl_view: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
         if(isInternetRechable)
         {
             Home_APi()
         }
        else
        {
             print("type==2")
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func Home_APi(){
        let header = ["Content-Type":"application/json"]
       
        //SVProgressHUD.show()
        let urlString = "https://api.flickr.com/services/feeds/photos_public.gne?format=json&tags=dogs&nojsoncallback=1#"
        print(urlString)
        request(urlString, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: header).responseString(completionHandler: { (response) in
            //SVProgressHUD.dismiss()
            let value = response.result.value!
            let json = self.convertToDictionary(text: value )
            if json != nil {
                let comment = json
                let data  = comment! as [String : AnyObject]
                self.ItemsArray = data["items"] as! NSArray
                print(self.ItemsArray)
                self.tbl_view.reloadData()
                

//                if self.page == 1
//                {
//                    self.ResultArray  =  (data["results"] as! NSArray).mutableCopy()as! NSMutableArray
//                }
//                else
//                {
//                    let array = data["results"] as! NSArray
//                    self.ResultArray.addObjects(from: array as! [Any])
//                }
//                self.NoPage = Int(ceil(Double(self.ResultArray.count/20)))
//                if(self.page <= self.NoPage)
//                {
//                    self.page = self.page + 1
//                    self.Home_APi()
//                }
//                self.tbl_view.reloadData()
                
            }
        })
    }
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        //dispaly data for uitableview
         if(!isInternetRechable)
        {
            resultData = Modeldata.getInstance().getAllData()
            tbl_view.reloadData()
        }
        
    }
        
    // number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       if(isInternetRechable)
        {
            return self.ItemsArray.count
        }else
        {
            return resultData.count
        }
    }
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        // set the text from the data model
       
       
        if(isInternetRechable)
        {
             let Title = self.ItemsArray[indexPath.row] as! [String:AnyObject]
            cell.lbl_title.text = (Title["title"] as! String)
            let demo : democlass = democlass()
            demo.title = (Title["title"] as! String)
            let isInserted = Modeldata.getInstance().addPersonData(personinfo: demo)
        }
        else
        {
             let Data : democlass = resultData.object(at: indexPath.row) as! democlass
             cell.lbl_title.text = Data.title
        }
        
//        if isInserted {
//
//            let alert = UIAlertController(title: "Successful", message: "Record Inserted successfully", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: { _ in
//
//            }))
//            present(alert, animated: true, completion: nil)
//            print("Record Inserted successfully.")
//
//
//
//        } else {
//            let alert = UIAlertController(title: "Failed", message: "You are Cannot Inserted", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
//            present(alert, animated: true, completion: nil)
//            print("Error in inserting record.")
//        }
        
       // ModelManager.getInstance().addPersonData(personinfo: demo)
        
        
        return cell
    }
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("You tapped cell number \(indexPath.row).")
    }
    
    

}


