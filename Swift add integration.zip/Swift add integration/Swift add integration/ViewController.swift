//
//  ViewController.swift
//  Swift add integration
//
//  Created by Chirag Patel on 4/24/18.
//  Copyright © 2018 PCHIRAG. All rights reserved.
//

import UIKit
import GoogleMobileAds

class ViewController: UIViewController,GADBannerViewDelegate,GADInterstitialDelegate {
    @IBOutlet var BanerView: GADBannerView!
    @IBOutlet var bannerviewHeight: NSLayoutConstraint!
    var interstitial: GADInterstitial!
    var BannerView: GADBannerView!
    override func viewDidLoad() {
        super.viewDidLoad()
        CreateBanner()
        CreateandloadInterstitial()
        bannerviewHeight.constant = 0
        // Do any additional setup after loading the view, typically from a nib.
    }
    func CreateBanner(){
        let request = GADRequest()
        BannerView = GADBannerView(adSize: kGADAdSizeBanner)
        BannerView.adUnitID = Constant.AddBanner_Test
        BannerView.rootViewController = self
        BannerView.delegate = self
        BannerView.frame = CGRect(x: 0, y: 0, width: view.frame.size.width, height: 49)
        BannerView.load(request)
    }
    func adViewDidReceiveAd(_ bannerView: GADBannerView) {
        BanerView.addSubview(BannerView!)
        bannerviewHeight.constant = 49
    }
    func adView(_ bannerView: GADBannerView,
                didFailToReceiveAdWithError error: GADRequestError) {
        bannerviewHeight.constant = 0
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func CreateandloadInterstitial(){
    interstitial = GADInterstitial(adUnitID: Constant.AddInti_Test)
    interstitial.delegate = self
    interstitial.load(GADRequest())
    }
    func interstitialDidReceiveAd(_ ad: GADInterstitial) {
        
    }
    func displayAd(_ ad: GADInterstitial?, isDisplay: Bool) {
        
                if isDisplay {
                    var topController: UIViewController? = UIApplication.shared.keyWindow?.rootViewController
                    while ((topController?.presentedViewController) != nil) {
                        topController = topController?.presentedViewController
                    }
                    interstitial.present(fromRootViewController: self)
                }
    }
    func interstitial(_ ad: GADInterstitial, didFailToReceiveAdWithError error: GADRequestError) {
        print(error)
    }
    
    func interstitialDidDismissScreen(_ ad: GADInterstitial) {
        print("Dissmiss")
        CreateandloadInterstitial()
    }
    
    @IBAction func loadads(_ sender: Any)
    {
     if CommonUtils.isDataSourceAvailable()
     {
        if interstitial.isReady
        {
           self.displayAd(interstitial, isDisplay: true)
        }else
        {
           print("add not ready")
        }
       }else
       {
       print("add not ready")
      }
    }
}

