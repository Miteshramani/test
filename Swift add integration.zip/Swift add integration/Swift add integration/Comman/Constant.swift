//
//  WebAPI.swift
//  FlipNpik
//
//  Created by Nirmal Choudhari on 17/03/16.
//  Copyright © 2016 iOS Developer. All rights reserved.
//

import Foundation

struct Constant {
    static let AddBanner_Test: String = "ca-app-pub-3940256099942544/2934735716"
    static let AddBanner_Live: String =  ""
    static let AdsBanner: String = AddBanner_Test
    static let AddInti_Test: String = "ca-app-pub-3940256099942544/4411468910"
    static let AddInti_Live: String =  ""
    static let AdsInti: String = AddInti_Test
}
