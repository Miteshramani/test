//
//  CommonUtils.h
//  Created by Silver

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <ifaddrs.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>
static bool isInternetReachable;
@interface CommonUtils : NSObject

+(void)placeholdercolor:(UITextField *)textfield Color:(UIColor *)Color Text:(NSString *)text;
+(void)textborder:(UITextField *)textfield Color:(UIColor *)Color width:(NSUInteger)with cornerradus:(NSInteger)rediaus;
+(void)btnborder:(UIButton *)button Color:(UIColor *)Color width:(NSUInteger)with cornerradus:(NSInteger)rediaus;
+(void)viewborder:(UIView *)button Color:(UIColor *)Color width:(NSUInteger)with cornerradus:(NSInteger)rediaus;
+(NSString *)getIPAddress;
+(NSString *)getMacAddress;
+(UIColor*)colorWithHexString:(NSString*)hex alpha:(float)alpha;
+(void)putspceLeft:(UITextField *)textfield;
+(void)Assingshedow:(UIButton *)shedowview;
+(void)Assingshedow1:(UIToolbar *)shedowview;
+(void)Assingshedow2:(UIView *)shedowview;
+(void)imagecolorcheange:(UIImage *)buttonImg color:(UIColor *)color button:(UIButton*)btn;
+ (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;

+ (void)internetReachabilityCheckNotifier;
+ (BOOL)isDataSourceAvailable;

@end
