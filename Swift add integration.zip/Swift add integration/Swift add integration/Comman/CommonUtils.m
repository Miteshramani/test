//
//  CommonUtils.h
//  Created by Silver


#import "CommonUtils.h"
#import "Reachability.h"
@implementation CommonUtils

+(void)putspceLeft:(UITextField *)textfield
{
    UILabel * leftView = [[UILabel alloc] initWithFrame:CGRectMake(10,0,7,26)];
    leftView.backgroundColor = [UIColor clearColor];
    textfield.leftView = leftView;
    textfield.leftViewMode = UITextFieldViewModeAlways;
    textfield.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
}

+(void)placeholdercolor:(UITextField *)textfield Color:(UIColor *)Color Text:(NSString *)text
{
    textfield.attributedPlaceholder = [[NSAttributedString alloc] initWithString:text attributes:@{NSForegroundColorAttributeName: Color}];
}
+(void)viewborder:(UIView *)button Color:(UIColor *)Color width:(NSUInteger)with cornerradus:(NSInteger)rediaus
{
    button.layer.cornerRadius=rediaus;
    button.layer.borderColor=Color.CGColor;
    button.layer.borderWidth=with;
    button.layer.masksToBounds=YES;
}
+(void)textborder:(UITextField *)textfield Color:(UIColor *)Color width:(NSUInteger)with cornerradus:(NSInteger)rediaus
{
textfield.layer.cornerRadius=rediaus;
textfield.layer.borderColor=Color.CGColor;
textfield.layer.borderWidth=with;
textfield.layer.masksToBounds=YES;
}

+(void)btnborder:(UIButton *)button Color:(UIColor *)Color width:(NSUInteger)with cornerradus:(NSInteger)rediaus
{
    button.layer.cornerRadius=rediaus;
    button.layer.borderColor=Color.CGColor;
    button.layer.borderWidth=with;
    button.layer.masksToBounds=NO;
    
}
+(NSString *)getIPAddress {
    
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while(temp_addr != NULL) {
            if(temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                    
                }
                
            }
            
            temp_addr = temp_addr->ifa_next;
        }
    }
    // Free memory
    freeifaddrs(interfaces);
    return address;
    
}
+(NSString *)getMacAddress
{
   return [[[UIDevice currentDevice] identifierForVendor] UUIDString];
}
+(UIColor*)colorWithHexString:(NSString*)hex alpha:(float)alpha
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor grayColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:alpha];
}
+(void)Assingshedow2:(UIView *)shedowview
{
    shedowview.layer.masksToBounds = NO;
    shedowview.layer.shadowOffset = CGSizeMake(1, 1);
    shedowview.layer.shadowRadius = 2.0;
    shedowview.layer.shadowOpacity = 0.8;
}
+(void)Assingshedow:(UIButton *)shedowview
{
    shedowview.layer.masksToBounds = NO;
    shedowview.layer.shadowOffset = CGSizeMake(1, 1);
    shedowview.layer.shadowRadius = 5.0;
    shedowview.layer.shadowOpacity = 0.8;
}
+(void)Assingshedow1:(UIToolbar *)shedowview
{
    shedowview.layer.masksToBounds = NO;
    shedowview.layer.shadowOffset = CGSizeMake(1, 1);
    shedowview.layer.shadowRadius = 5.0;
    shedowview.layer.shadowOpacity = 0.8;
}
+(void)imagecolorcheange:(UIImage *)buttonImg color:(UIColor *)color button:(UIButton*)btn
{
    UIImage *image1 = [buttonImg imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    [btn setImage:image1 forState:UIControlStateNormal];
    btn.tintColor = color;
}
+ (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {
   
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}
+ (void)internetReachabilityCheckNotifier
{
    Reachability *internetReachable = [Reachability reachabilityWithHostname:@"www.google.com"];
    
    //Parse Host - https://api.parse.com
    //Google Host - www.google.com
    
    // Internet is reachable
    internetReachable.reachableBlock = ^(Reachability*reach)
    {
        isInternetReachable = YES;
        // Update the UI on the main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            NSLog(@"Internet Connected ON!");
        });
    };
    
    // Internet is not reachable
    internetReachable.unreachableBlock = ^(Reachability*reach)
    {
        isInternetReachable = NO;
        // Update the UI on the main thread
        dispatch_async(dispatch_get_main_queue(), ^{
            NSLog(@"Internet Connection OFF ");
            
        });
    };
    [internetReachable startNotifier];
}

+ (BOOL)isDataSourceAvailable
{
    return isInternetReachable;
}
@end
