//
//  EDITViewController.swift
//  Product
//
//  Created by iblinfotech on 27/02/18.
//  Copyright © 2018 iblinfotech. All rights reserved.
//

import UIKit

class EDITViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    //Mark:- Outlet
    @IBOutlet weak var image_product: UIImageView!
    @IBOutlet weak var txt_name: UITextField!
    @IBOutlet weak var txt_company: UITextField!
    @IBOutlet weak var txt_price: UITextField!
    @IBOutlet weak var txt_description: UITextField!
    @IBOutlet weak var editOut: UIBarButtonItem!
    @IBOutlet weak var imagebtn_outlet: UIButton!
    
    var resultProductData : NSMutableArray!
    var name = String()
    var company = String()
    var price = String()
    var descriptionn = String()
    var IndexEdit = Int()
    var Image = ""
    
    
    
    //ImagePicker
    let imagepicker = UIImagePickerController()
    
    //Image
    var pickedImage : UIImage!
    var decodedimage = UIImage()
    var checkImage = UIImage()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //Mark:- Imagepicker delegate
        imagepicker.delegate = self
        
        
        txt_name.text = name
        txt_company.text = company
        txt_price.text = price
        txt_description.text = descriptionn
        
        if Image == ""
        {
            image_product.image = #imageLiteral(resourceName: "Shopping-icon")
        }
        else
        {
            let strBase64 = Image
            let dataDecoded : Data = Data(base64Encoded: strBase64, options: .ignoreUnknownCharacters)!
            decodedimage = UIImage(data: dataDecoded)!
            
            self.image_product.image = decodedimage
        }
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        resultProductData = NSMutableArray()
        resultProductData = ModelManager.getInstance().getAllProductData()
    }
    
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func editBtn(_ sender: UIBarButtonItem) {
        if editOut.title == "Edit"
        {
            editOut.title = "Save"
            txt_name.isEnabled = true
            txt_company.isEnabled = true
            txt_price.isEnabled = true
            txt_description.isEnabled = true
            imagebtn_outlet.isEnabled = true
           
        }
        else
        {
            
            if image_product.image != decodedimage
            {
                checkImage = pickedImage
                
                UpdateBtn()
            }
            else
            {
                checkImage = image_product.image!
                UpdateBtn()
            }
            
            txt_name.text = ""
            txt_price.text = ""
            txt_company.text = ""
            txt_description.text = ""
        }
        
    }
    
    
    @IBAction func doneBtn(_ sender: UIBarButtonItem) {
            dismiss(animated: true, completion: nil)
    }
    
    
    func UpdateBtn()
    {
    
            let productinfo : ProductInfo = ProductInfo()

            let imageData:NSData = UIImagePNGRepresentation(checkImage)! as NSData
            let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
            
            let productdata = resultProductData.object(at: IndexEdit) as! ProductInfo
            productinfo.id = productdata.id
            productinfo.name = txt_name.text!
            productinfo.price = txt_price.text!
            productinfo.company = txt_company.text!
            productinfo.discription = txt_description.text!
            productinfo.image = strBase64
            
            let isUpdated = ModelManager.getInstance().updateProductData(productinfo: productinfo)
            
            if isUpdated {
                let alert = UIAlertController(title: "Successful", message: "Product successfully Updated", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .destructive, handler: { (action) in
                    self.dismiss(animated: true, completion: nil)
                }))
                
                present(alert, animated: true, completion: nil)
                
                print("Record Updated successfully.")
                
                
            } else {
                print("Error in inserting record.")
            }
   
    }
    
    
    @IBAction func imageBtn_edit(_ sender: UIButton) {
        let alert = UIAlertController(title: "Choose Source Type", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.OpenCamera()
        }))
        alert.addAction(UIAlertAction(title: "Photo Gallery", style: .default, handler: { _ in
            self.OpenGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    
    //Mark:- imagepicker ------------------------------------------------------------------------------------------------------------
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        if pickedImage != nil
        {
            image_product.contentMode = .scaleAspectFit
            image_product.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func OpenGallery()
    {
        imagepicker.allowsEditing = true
        imagepicker.sourceType = .photoLibrary
        
        present(imagepicker, animated: true, completion: nil)
    }
    func OpenCamera()
    {
        if(UIImagePickerController.isSourceTypeAvailable(.camera))
        {
            imagepicker.allowsEditing = true
            imagepicker.sourceType = .camera
            present(imagepicker, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Warning !", message: "Camera Not Available On Your Device", preferredStyle: .alert)
            alert.addAction((UIAlertAction(title: "Ok", style: .cancel, handler: nil)))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
}
