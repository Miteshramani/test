//
//  ProductCell.swift
//  Product
//
//  Created by iblinfotech on 28/02/18.
//  Copyright © 2018 iblinfotech. All rights reserved.
//

import UIKit

class ProductCell: UITableViewCell {

    @IBOutlet weak var lbl_name: UILabel!
    @IBOutlet weak var lbl_price: UILabel!
    @IBOutlet weak var img_product: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
