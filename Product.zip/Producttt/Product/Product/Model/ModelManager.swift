//
//  ModelManager.swift
//  DataBaseDemo
//
//  Created by Krupa-iMac on 05/08/14.
//  Copyright (c) 2014 TheAppGuruz. All rights reserved.
//

import UIKit

let sharedInstance = ModelManager()

class ModelManager: NSObject {
    
    var database: FMDatabase? = nil

    class func getInstance() -> ModelManager
    {
        if(sharedInstance.database == nil)
        {
            let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("product.sqlite").path
            sharedInstance.database = FMDatabase(path: path)
            print(path)
            
        }
        return sharedInstance
    }
    
    //add data
    func addPersonData(personinfo: PersonInfo) -> Bool {
        sharedInstance.database!.open()
        
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO person (name, email, password, image, gender, birthdate, country) VALUES ( ?, ?, ?, ?, ?, ?, ?)", withArgumentsIn: [personinfo.name, personinfo.email, personinfo.password,personinfo.image, personinfo.gender, personinfo.birthdate, personinfo.country])
        sharedInstance.database!.close()
        return isInserted
    }
    
    func addProductData(productinfo: ProductInfo) -> Bool {
        sharedInstance.database!.open()
        //let personinfo : PersonInfo = PersonInfo()
        let isInserted = sharedInstance.database!.executeUpdate("INSERT INTO product (name, image, price, company, description) VALUES (?, ?, ?, ?, ?)", withArgumentsIn: [productinfo.name, productinfo.image, productinfo.price, productinfo.company, productinfo.discription])
        sharedInstance.database!.close()
        return isInserted
    }
    
    
   // Update Data
    func updateProductData(productinfo: ProductInfo) -> Bool {
        sharedInstance.database!.open()
        let isUpdated = sharedInstance.database!.executeUpdate("UPDATE product SET name=?, image=?, price=?, company=?, description=? WHERE id=?", withArgumentsIn: [productinfo.name, productinfo.image, productinfo.price, productinfo.company, productinfo.discription, productinfo.id])
        sharedInstance.database!.close()
        return isUpdated
    }
    
    
    
    //Delete Data
    func deleteProductData(productinfo: ProductInfo) -> Bool {
        sharedInstance.database!.open()
        let isDeleted = sharedInstance.database!.executeUpdate("DELETE FROM product WHERE id=?", withArgumentsIn: [productinfo.id])
        sharedInstance.database!.close()
        return isDeleted
    }
   

    
    //Get All Data for Product
    func getAllProductData() -> NSMutableArray {
        sharedInstance.database!.open()
        //let personinfo : PersonInfo = PersonInfo()
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM product", withArgumentsIn: [])
        let resultProductInfo : NSMutableArray = NSMutableArray()
        if (resultSet != nil) {
            while resultSet.next() {
                let productinfo : ProductInfo = ProductInfo()
                productinfo.id = resultSet.string(forColumn: "id")!
                productinfo.name = resultSet.string(forColumn: "name")!
                productinfo.image = resultSet.string(forColumn: "image")!
                productinfo.price = resultSet.string(forColumn: "price")!
                productinfo.company = resultSet.string(forColumn: "company")!
                productinfo.discription = resultSet.string(forColumn: "description")!
                
                resultProductInfo.add(productinfo)
            }
        }
        sharedInstance.database!.close()
        return resultProductInfo
    }
    
    
    //Get All Data for Person
    func getAllLoginData() -> NSMutableArray {
        sharedInstance.database!.open()
        let resultSet: FMResultSet! = sharedInstance.database!.executeQuery("SELECT * FROM person", withArgumentsIn: [])
        let resultPersonInfo : NSMutableArray = NSMutableArray()
        if (resultSet != nil) {
            while resultSet.next() {
                let personinfo : PersonInfo = PersonInfo()
                personinfo.id = resultSet.string(forColumn: "id")!
                personinfo.name = resultSet.string(forColumn: "name")!
                personinfo.email = resultSet.string(forColumn: "email")!
                personinfo.password = resultSet.string(forColumn: "password")!
                personinfo.gender = resultSet.string(forColumn: "gender")!
                personinfo.birthdate = resultSet.string(forColumn: "birthdate")!
                //personinfo.image = resultSet.string(forColumn: "image")!
                personinfo.country = resultSet.string(forColumn: "country")!
                resultPersonInfo.add(personinfo)
            }
        }
        sharedInstance.database!.close()
        return resultPersonInfo
    }
    
    
  
}
