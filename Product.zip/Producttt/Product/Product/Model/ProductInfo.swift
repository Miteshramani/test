//
//  ProductInfo.swift
//  Product
//
//  Created by iblinfotech on 27/02/18.
//  Copyright © 2018 iblinfotech. All rights reserved.
//

import UIKit

class ProductInfo: NSObject {

    var id : String = String()
    var name : String = String()
    var image : String = String()
    var price : String = String()
    var company : String = String()
    var discription : String = String()
    var personid : String = String()
    
    
}

