//
//  RegisterInfo.swift
//  Product
//
//  Created by iblinfotech on 27/02/18.
//  Copyright © 2018 iblinfotech. All rights reserved.
//

import UIKit

class PersonInfo: NSObject {
    
    var id : String = String()
    var name : String = String()
    var email : String = String()
    var password : String = String()
    var gender : String = String()
    var birthdate : String = String()
    var image : String = String()
    var country : String = String()
   
}

