//
//  ADDViewController.swift
//  Product
//
//  Created by iblinfotech on 27/02/18.
//  Copyright © 2018 iblinfotech. All rights reserved.
//

import UIKit

class ADDViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    //Mark:- Outlet
    
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var txt_name: UITextField!
    @IBOutlet weak var txt_price: UITextField!
    @IBOutlet weak var txt_company: UITextField!
    @IBOutlet weak var txt_description: UITextField!
    
    var resultProductData = NSMutableArray()
    
    //ImagePicker
    let imagepicker = UIImagePickerController()
    
    //Image
    var pickedImage : UIImage!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        //Mark:- Imagepicker delegate
        imagepicker.delegate = self
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func ImageBtn(_ sender: UIButton) {
        let alert = UIAlertController(title: "Choose Source Type", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.OpenCamera()
        }))
        alert.addAction(UIAlertAction(title: "Photo Gallery", style: .default, handler: { _ in
            self.OpenGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func doneBtn(_ sender: UIBarButtonItem) {
        
        let name = txt_name.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let price = txt_price.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let company = txt_company.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let description = txt_description.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if (name?.isEmpty)! || (price?.isEmpty)! || (company?.isEmpty)! || (description?.isEmpty)!
        {
            let alert = UIAlertController(title: "Warning !", message: "Please Provide All Field", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
          
        }
        else
        {
            self.saveBtn()
            self.dismiss(animated: true, completion: nil)
        }
        
       
    }
    
    //Mark:- Done btn Event -------------------------------------------------
    func saveBtn()
    {
        
        
        let imageData:NSData = UIImagePNGRepresentation(pickedImage)! as NSData
        let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
        
        let productinfo : ProductInfo = ProductInfo()
        productinfo.name = txt_name.text!
        productinfo.price = "\(txt_price.text!)$"
        productinfo.company = txt_company.text!
        productinfo.discription = txt_description.text!
        productinfo.image = strBase64
        
        
        let isInserted = ModelManager.getInstance().addProductData(productinfo: productinfo)
        if isInserted {
            
            let alert = UIAlertController(title: "Successful", message: "Product successfully Added", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .destructive, handler: nil))
            
            
            print("Product Inserted successfully.")
            txt_name.text = ""
            txt_price.text = ""
            txt_company.text = ""
            txt_description.text = ""
            
        } else {
            print("Error in inserting record.")
        }
        
    }
    @IBAction func cancelBtn(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    
    //Mark:- imagepicker ------------------------------------------------------------------------------------------------------------
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        if pickedImage != nil
        {
            image.contentMode = .scaleAspectFit
            image.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func OpenGallery()
    {
        imagepicker.allowsEditing = true
        imagepicker.sourceType = .photoLibrary
        
        present(imagepicker, animated: true, completion: nil)
    }
    func OpenCamera()
    {
        if(UIImagePickerController.isSourceTypeAvailable(.camera))
        {
            imagepicker.allowsEditing = true
            imagepicker.sourceType = .camera
            present(imagepicker, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Warning !", message: "Camera Not Available On Your Device", preferredStyle: .alert)
            alert.addAction((UIAlertAction(title: "Ok", style: .cancel, handler: nil)))
            self.present(alert, animated: true, completion: nil)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
