//
//  SingUpViewController.swift
//  Product
//
//  Created by iblinfotech on 27/02/18.
//  Copyright © 2018 iblinfotech. All rights reserved.
//

import UIKit

class SingUpViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {

    //Outlet
    
    @IBOutlet weak var txt_name: UITextField!
    @IBOutlet weak var txt_pass: UITextField!
    @IBOutlet weak var txt_email: UITextField!
    @IBOutlet weak var txt_birth: UITextField!
    @IBOutlet weak var txt_gender: UITextField!
    @IBOutlet weak var txt_country: UITextField!
    @IBOutlet weak var profilrImage: UIImageView!
    
    
    //DatePicker
    let datepicker = UIDatePicker()
    
    //ImagePicker
    let imagepicker = UIImagePickerController()
    
    //Pickerview with Gender Array
    let pickerview = UIPickerView()
    let GenderArr = ["Male","Female"]
    let CountryArr = ["India","USA","UK","Australia","Canada","Germany","Czech Republic","Poland","Denmark"]
    var CurrentArr : [String] = []
    
    //Mark:- TextField Variable
    var CurrentText : UITextField!
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ShowDatepicker()
        
        //Mark:- Imagepicker delegate
        imagepicker.delegate = self
        
        //Mark:- Pickerview delegate
        pickerview.delegate = self
        pickerview.dataSource = self
        
        //Mark:- TextFIeld Delegate
        txt_gender.delegate = self
        txt_country.delegate = self
        
        
        
        
        // Do any additional setup after loading the view.
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func SignUpBtn(_ sender: UIButton) {
       
        let name = txt_name.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let email = txt_email.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let pass = txt_pass.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let gender = txt_gender.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let birthdate = txt_birth.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let country = txt_country.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        
        if (name?.isEmpty)! || (email?.isEmpty)! || (pass?.isEmpty)! || (gender?.isEmpty)! || (birthdate?.isEmpty)! || (country?.isEmpty)!
        {
            let alert = UIAlertController(title: "Warning !", message: "Please Provide All Field", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .destructive, handler: nil))
            present(alert, animated: true, completion: nil)
            
        }
        else
        {
            let personinfo : PersonInfo = PersonInfo()
            personinfo.name = txt_name.text!
            personinfo.email = txt_email.text!
            personinfo.password = txt_pass.text!
            personinfo.gender = txt_gender.text!
            personinfo.birthdate = txt_birth.text!
            personinfo.country = txt_country.text!
            
            let isInserted = ModelManager.getInstance().addPersonData(personinfo: personinfo)
            
            if isInserted {
                
                let alert = UIAlertController(title: "Successful", message: "You are successfully Registered", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: { _ in
                    self.performSegue(withIdentifier: "regToDash", sender: self)
                }))
                present(alert, animated: true, completion: nil)
                print(personinfo)
                print("Record Inserted successfully.")
                txt_name.text = ""
                txt_email.text = ""
                txt_pass.text = ""
                txt_gender.text = ""
                txt_birth.text = ""
                txt_country.text = ""
                
                
            } else {
                let alert = UIAlertController(title: "Failed", message: "You are Cannot Registered", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
                present(alert, animated: true, completion: nil)
                print("Error in inserting record.")
            }
            
        }
        
    }
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "regToDash"
//        {
//
//        }
//
//
//
//    }
    
    
    
    @IBAction func loginBtn(_ sender: UIButton) {
        performSegue(withIdentifier: "SignUpTOLogin", sender: self)
    }
    
    func ShowDatepicker() {
        datepicker.datePickerMode = .date
        
        //toolbar ----------------
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let done = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(DoneButtonClicked))
        let space = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let cancel = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(CancelClicked))
        toolbar.setItems([done,space,cancel], animated: true)
        
        //add toolbar to textfield -----------
        txt_birth.inputAccessoryView = toolbar
        
        //add datepicker to textfield -------------
        txt_birth.inputView = datepicker
        
        //add pickerview to textfield --------------
        txt_gender.inputView = pickerview
        txt_country.inputView = pickerview
        
    }
    @objc func DoneButtonClicked()
    {
        //let formator
        let formattor = DateFormatter()
        formattor.dateFormat = "dd/MM/yyyy"
        
        //assign format to textfield
        txt_birth.text = formattor.string(from: datepicker.date)
        self.view.endEditing(true)
        
    }
    @objc func CancelClicked()
    {
        self.view.endEditing(true)
    }
    
    
    
    @IBAction func profileBtn(_ sender: UIButton) {
        
        let alert = UIAlertController(title: "Choose Source Type", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.OpenCamera()
        }))
        alert.addAction(UIAlertAction(title: "Photo Gallery", style: .default, handler: { _ in
            self.OpenGallery()
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
        
    }
    
    
    //Mark:- imagepicker ------------------------------------------------------------------------------------------------------------
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage
        {
            profilrImage.contentMode = .scaleAspectFit
            profilrImage.image = pickedImage
        }
        dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    func OpenGallery()
    {
        imagepicker.allowsEditing = true
        imagepicker.sourceType = .photoLibrary
        present(imagepicker, animated: true, completion: nil)
    }
    func OpenCamera()
    {
        if(UIImagePickerController.isSourceTypeAvailable(.camera))
        {
            imagepicker.allowsEditing = true
            imagepicker.sourceType = .camera
            present(imagepicker, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Warning !", message: "Camera Not Available On Your Device", preferredStyle: .alert)
            alert.addAction((UIAlertAction(title: "Ok", style: .cancel, handler: nil)))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    //Mark:- gender and country picker ------------------------------------------------------------------------------------------
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        CurrentText = textField
        switch textField {
        case txt_gender:
            CurrentArr = GenderArr
        case txt_country:
            CurrentArr = CountryArr
        default:
            print("Default")
        }
        pickerview.reloadAllComponents()
        
        
     return true
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
  
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return CurrentArr.count
    }
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        CurrentText.text = CurrentArr[row]
        
        return CurrentText.text
    }
    
    
    
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
