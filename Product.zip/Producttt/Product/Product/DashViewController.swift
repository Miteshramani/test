//
//  DashViewController.swift
//  Product
//
//  Created by iblinfotech on 27/02/18.
//  Copyright © 2018 iblinfotech. All rights reserved.
//

import UIKit

class DashViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tableview: UITableView!
    
    
    //Mark:- Get data into nsmutable Array
    var resultProductData = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    //Mark:- Get DATA Before view load
    override func viewWillAppear(_ animated: Bool) {
       // let productinfo : ProductInfo = ProductInfo()
        resultProductData = ModelManager.getInstance().getAllProductData()
        tableview.reloadData()
        tableview.tableFooterView = UIView()
       
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func LogOutBtn(_ sender: UIBarButtonItem) {
        if let appdelegate: AppDelegate = UIApplication.shared.delegate as? AppDelegate {
            appdelegate.Logout()
        }
    }
    
    @IBAction func AddBarBtn(_ sender: UIBarButtonItem) {
      
        performSegue(withIdentifier: "add_segue", sender: self)
    }
    
    
    
    
    
    //MARK:- TABLE VIEW -------------------------------------------------------------------------------
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resultProductData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "product_cell", for: indexPath) as! ProductCell
        
        let productData : ProductInfo = resultProductData.object(at: indexPath.row) as! ProductInfo
        
        cell.lbl_name.text = productData.name
        cell.lbl_price.text = productData.price
        
        let dataDecoded : Data = Data(base64Encoded: productData.image, options: .ignoreUnknownCharacters)!
        let decodedimage = UIImage(data: dataDecoded)
        cell.img_product.image = decodedimage
        return cell
    }
    
    var Index = 0
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        Index = indexPath.row
        performSegue(withIdentifier: "view_segue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "view_segue"
        {
            let EditCOntroller = segue.destination as! EDITViewController
            let productData : ProductInfo = resultProductData.object(at: Index) as! ProductInfo
            EditCOntroller.IndexEdit = Index
            EditCOntroller.name = productData.name
            EditCOntroller.company = productData.company
            EditCOntroller.price = productData.price
            EditCOntroller.descriptionn = productData.discription
            EditCOntroller.Image = productData.image
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete
        {
            let productData : ProductInfo = resultProductData.object(at: indexPath.row) as! ProductInfo
            let isUpdated = ModelManager.getInstance().deleteProductData(productinfo: productData)
            if isUpdated {
                print("Record Deleted successfully.")
                
            } else {
                print("Error in Deleting record.")
            }
            resultProductData = ModelManager.getInstance().getAllProductData()
            tableview.reloadData()
        }
        
    }
    
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
