//
//  ViewController.swift
//  Product
//
//  Created by iblinfotech on 27/02/18.
//  Copyright © 2018 iblinfotech. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    //Outlet
    @IBOutlet weak var txt_name: UITextField!
    @IBOutlet weak var txt_pass: UITextField!
    var PersonData = NSMutableArray()
   
    

    override func viewDidLoad() {
        super.viewDidLoad()
       txt_name.text = "mayur@gmail.com"
        txt_pass.text = "123456"
    }

    
    override func viewWillAppear(_ animated: Bool) {
        PersonData = ModelManager.getInstance().getAllLoginData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //Mark:- Login Btn --------------------------------------------------------------------
    @IBAction func LoginBtn(_ sender: UIButton) {
        var isLogin = false
        for i in 0..<PersonData.count
        {
            let CheckLogin : PersonInfo = PersonData.object(at: i) as! PersonInfo
            if CheckLogin.email == txt_name.text && CheckLogin.password == txt_pass.text
            {
                isLogin = true
                break;
            }
        }
        
        if isLogin
        {
            UserDefaults.standard.set(true, forKey: "isLogin")
            performSegue(withIdentifier: "loginToDash", sender: self)
            txt_name.text = ""
            txt_pass.text = ""
        }
        else
        {
            let alert = UIAlertController(title: "Sorry !", message: "Email Or Password Wrong", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .destructive, handler: nil))
            present(alert, animated: true, completion: nil)
            
        }
        
    }
 
    
    @IBAction func SignUpBtn(_ sender: UIButton) {
        
        performSegue(withIdentifier: "LoginTORegister", sender: self)
    }
  
}

